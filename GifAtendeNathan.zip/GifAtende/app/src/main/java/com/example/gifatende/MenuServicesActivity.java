package com.example.gifatende;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MenuServicesActivity extends AppCompatActivity {

    ImageButton subMenuOpen;

    Button serviceOne;
    Button serviceTwo;
    Button serviceThree;
    Button serviceFour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_services);



        ImageButton subMenuOpen = findViewById(R.id.subMenuOpen);



        Button serviceOne = findViewById(R.id.serviceOne);
        Button serviceTwo = findViewById(R.id.serviceTwo);
        Button serviceThree = findViewById(R.id.serviceThree);
        Button serviceFour = findViewById(R.id.serviceFour);


        //TODO: criar intent  para todos os serviços
        serviceOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        //TODO: criar intent  para todos os serviços
        serviceTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        //TODO: criar intent  para todos os serviços
        serviceThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        //TODO: criar intent  para todos os serviços
        serviceFour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


        //metodo de onclick exemplo:
        //TODO: submenu ja feito.
        subMenuOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuServicesActivity.this, SubMenuGroup.class);
                startActivity(i);
            }
        });

    }
}